301374509 ison Injun Son

I used STL list.

First of all, get integer lists, which is separated by 0.
So if I get '0', after that every integers should saved in list2.

In STL, there is an sorting algorithm which is usually O(nlogn).

So I sorted two different lists and remove all integers from list2 in list1.

Since I sorted before, the last element after removing is the largest number.

If there is no number in list1, than it should print out "NONE".